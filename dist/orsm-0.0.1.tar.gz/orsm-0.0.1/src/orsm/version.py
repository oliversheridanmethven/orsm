def repo_name():
    return "ORSM"


def repo_version():
    # TODO: Get the build or version control system to generate this...
    return "vX.Y.Z"


def repo_author():
    return "Dr Oliver Sheridan-Methven"


def repo_email():
    return "oliver.sheridan-methven@hotmail.co.uk"

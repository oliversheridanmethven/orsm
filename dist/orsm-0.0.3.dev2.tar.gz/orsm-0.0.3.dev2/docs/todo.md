# TODO



There are various things I would like to add to this repo, including:

- Git hooks:
  - Publishing documentation. 
  - Generating code documentation. 
  - Ensuring tests pass.
  - Code formatter.

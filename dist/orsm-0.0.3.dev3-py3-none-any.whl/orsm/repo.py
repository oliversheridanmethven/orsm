def repo_name():
    return "ORSM"


def repo_version():
    from ._version import version
    return version


def repo_author():
    return "Dr Oliver Sheridan-Methven"


def repo_email():
    return "oliver.sheridan-methven@hotmail.co.uk"

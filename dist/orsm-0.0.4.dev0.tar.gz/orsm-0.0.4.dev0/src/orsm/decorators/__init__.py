"""
Helpful things to do with decorators.
"""

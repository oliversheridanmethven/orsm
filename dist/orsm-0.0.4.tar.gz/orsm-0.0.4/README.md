# Home

## Author

Dr Oliver Sheridan-Methven 
[oliver.sheridan-methven@hotmail.co.uk](mailto:oliver.sheridan-methven@hotmail.co.uk).

## Description

A collection of various code snippets that are frequently 
useful (or entertaining). 

## Documentation 

The full documentation can be found here: [Documentation](https://oliversheridanmethven.github.io/orsm/).
